|Name | Field of Action|
--- | --- |
| ConnorAU, shukari, linkion, Hypoxic, hypoxia125, anthonybartczak, klausman, Pixelated-Grunt | Scripting |
| mihuan-0 | Chinese Translation |
| XerXesCZ | Czech Translation |
| Poslovitch, Alfred-Neuman | French Translation |
| GhostJumper, Mr-Melker | German Translation |
| zagor64bz, Fil-ric | Italian Translation |
| Kofeina101, Krzyciu, genjonakasone | Polish Translation |
| Counserf | Russian Translation |
| arv187, regiregi22 | Spanish Translation |
| Leopard20 | Providing his blank font |
| lex__1 |
| niquenensolentis |
| pokertour |
| SynchronizedHD |
| TaktischerSpeck |
| Theassassinzz |
| IllidanS4 |
| Jason Bert |
| KiritoKun223 |
| dardothemaster |
| dixon13 |
| 11RDP |
| LoupVert |
| 2RIMa |
| KJW/SpicyBagpipes |
| PapaBear |
| a1044438870 |
| Artenis |
| Pixelated Grunt | minor ESE improvement |
| Dart | Config |
