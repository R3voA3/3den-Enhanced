class Date
{
	class Attributes
	{
		class Enh_TimeMultiplier
		{
			displayName = $STR_timeMultiplier_displayName;
			tooltip = $STR_timeMultiplier_tooltip;
			property = "Enh_timeMultiplier";
			control = "Enh_SliderTimeMultiplier";
			expression = "if (!is3DEN) then {setTimeMultiplier _value}";
			defaultValue = "1";
		};
	};
};
