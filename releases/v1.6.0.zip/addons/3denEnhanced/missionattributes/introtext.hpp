class Enh_IntroText
{
	displayName = $STR_introText_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_IntroDelay
		{
			displayName = $STR_introText_introDelay_displayName;
			tooltip = $STR_introText_introDelay_tooltip;
			property = "Enh_introDelay";
			control = "Edit";
			expression =
			"\
				if ((_value > 0) && !is3DEN) then\
				{\
					_value spawn\
					{\
						waitUntil {time > _this};\
						[\
							parseText format\
							[\
								""<t align='right' size='1.6'><t font='PuristaBold' size='1.8'>%1<br/></t>%2<br/>%3</t>"",\
								(missionNamespace getVariable 'Enh_introLine1'),\
								(missionNamespace getVariable 'Enh_introLine2'),\
								(missionNamespace getVariable 'Enh_introLine3')\
							],\
							true\
						] remoteExec ['BIS_fnc_textTiles',[0,-2] select (isMultiplayer && isDedicated),true];\
					}\
				};\
			";
			defaultValue = "-1";
			typeName = "NUMBER";
		};
		class Enh_Line_1
		{
			displayName = $STR_introText_line1_displayName;
			tooltip = "";
			property = "Enh_firstLine";
			control = "Edit";
			expression = "missionNamespace setVariable ['Enh_introLine1',_value]";
			defaultValue = briefingName;
			typeName = "STRING";
		};
		class Enh_Line_2: Enh_Line_1
		{
			displayName = $STR_introText_line2_displayName;
			expression = "missionNamespace setVariable ['Enh_introLine2',_value]";
			property = 'Enh_line2';
			defaultValue = ('by ' + profileName);
		};
		class Enh_Line_3: Enh_Line_1
		{
			displayName = $STR_introText_line3_displayName;
			expression = "missionNamespace setVariable ['Enh_introLine3',_value]";
			property = 'Enh_line3';
			defaultValue = ([daytime] call BIS_fnc_TimeToString);
		};
	};
};
