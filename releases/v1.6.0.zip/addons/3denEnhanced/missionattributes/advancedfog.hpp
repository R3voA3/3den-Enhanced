class Enh_AdvancedFogSettings
{
	displayName = $STR_advancedFog_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_FogValue
		{
			displayName = $STR_advancedFog_FogValue_displayName;
			tooltip = $STR_advancedFog_FogValue_tooltip;
			property = "Enh_fogValue";
			control = "Slider";
			expression =
			"\
				if (_value > 0) then\
				{\
					_value spawn\
					{\
						waitUntil {time > 0.2};\
						0 setFog [_this,missionNamespace getVariable 'Enh_fogDecay',missionNamespace getVariable 'Enh_fogBase'];\
					};\
				};\
			";
			defaultValue = "0";
		};
		class Enh_FogDecay: Enh_FogValue
		{
			displayName = $STR_advancedFog_FogDecay_displayName;
			tooltip = $STR_advancedFog_FogDecay_tooltip;
			expression = "missionNamespace setVariable ['Enh_fogDecay',_value]";
			property = "Enh_fogDecay";
		};
		class Enh_FogBase: Enh_FogValue
		{
			displayName = $STR_advancedFog_FogBase_displayName;
			tooltip = $STR_advancedFog_FogBase_tooltip;
			property = "Enh_fogBase";
			control = "Edit";
			expression = "missionNamespace setVariable ['Enh_fogBase',_value]";
		};
	};
};
