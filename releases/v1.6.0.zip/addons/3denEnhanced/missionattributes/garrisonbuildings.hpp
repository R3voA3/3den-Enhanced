class Enh_GarrisonBuildings
{
	collapsed = 0;
	displayName = $STR_garrisonSettings_headline;
	class Attributes
	{
		class Enh_BuildingPosCoverage
		{
			displayName = $STR_buildingPosCoverage_displayName;
			tooltip = $STR_buildingPosCoverage_tooltip;
			property = "Enh_garrisonCoverage";
			control = "Enh_GarrisonCoverageCombo";
			expression = "";
			defaultValue = "1";
			typeName = "NUMBER";
		};
		class Enh_GarrisonRadius
		{
			displayName = $STR_garrisonRadius_displayName;
			tooltip = "";
			property = "Enh_garrisonRadius";
			control = "Enh_SliderGarrisonRadius";
			expression = "";
			defaultValue = "100";
			typeName = "NUMBER";
		};
	};
};
