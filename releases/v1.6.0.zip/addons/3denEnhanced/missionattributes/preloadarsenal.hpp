class Enh_PreloadArsenal
{
	displayName =  $STR_preloadArsenal_displayName;
	tooltip = $STR_preloadArsenal_tooltip;
	property = "Enh_preloadArsenal";
	control = "Checkbox";
	expression =
	"\
		if (_value) then\
		{\
			['Preload'] call BIS_fnc_arsenal;\
			add3DENEventhandler ['onMissionPreviewEnd',{['Preload'] call BIS_fnc_arsenal}];\
			add3DENEventhandler ['onMissionPreviewEnd',{['Preload'] call BIS_fnc_arsenal}];\
		};\
	";
	defaultValue = "false";
};
