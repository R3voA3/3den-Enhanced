class Enh_AdvancedEnding
{
	displayName = $STR_advancedEnding_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_EndingNameWin
		{
			displayName = $STR_advancedEnding_endingNameWin_displayName;
			tooltip = $STR_advancedEnding_endingName_tooltip;
			property = "Enh_advancedEnding_endingNameWin";
			expression =
			"\
				if (!(_value == '') && !is3DEN) then\
				{\
					_value spawn\
					{\
						_music = missionNamespace getVariable 'Enh_advancedEnding_playMusic';\
						_tasks = missionNamespace getVariable 'Enh_advancedEnding_cancelTasks';\
						_win = compileFinal (missionNamespace getVariable 'Enh_advancedEnding_ConditionWin');\
						\
						waitUntil {sleep 10; (call _win)};\
						[_this,true,nil,_music,_tasks] remoteExec ['BIS_fnc_endMission',0];\
					};\
				};\
			";
			control = "Enh_CfgDebriefingCombo";
			defaultValue = "";
		};
		class Enh_ConditionWin
		{
			displayName = $STR_advancedEnding_conditionWin_displayName;
			tooltip = $STR_advancedEnding_condition_tooltip;
			property = "Enh_advancedEnding_conditionWin";
			control = "EditCodeMulti5";
			expression = "missionNamespace setVariable ['Enh_advancedEnding_ConditionWin',_value]";
			typeName = "STRING";
			defaultValue = "false";
		};
		class Enh_EndingNameLose: Enh_EndingNameWin
		{
			displayName = $STR_advancedEnding_endingNameLose_displayName;
			property = "Enh_advancedEnding_endingNameLose";
			expression =
			"\
				if (!(_value == '') && !is3DEN) then\
				{\
					_value spawn\
					{\
						_music = missionNamespace getVariable 'Enh_advancedEnding_playMusic';\
						_tasks = missionNamespace getVariable 'Enh_advancedEnding_cancelTasks';\
						_win = compileFinal (missionNamespace getVariable 'Enh_advancedEnding_ConditionWin');\
						_lose = compileFinal (missionNamespace getVariable 'Enh_advancedEnding_ConditionLose');\
						\
						waitUntil {sleep 10; (call _lose)};\
						[_this,false,nil,_music,_tasks] remoteExec ['BIS_fnc_endMission',0];\
					};\
				};\
			";
		};
		class Enh_ConditionLose: Enh_ConditionWin
		{
			displayName = $STR_advancedEnding_conditionLose_displayName;
			expression = "missionNamespace setVariable ['Enh_advancedEnding_ConditionLose',_value]";
			property = "Enh_advancedEnding_conditionLose";
		};
		class Enh_PlayMusic
		{
			displayName = $STR_advancedEnding_playMusic_displayName;
			tooltip = $STR_advancedEnding_playMusic_tooltip;
			property = "Enh_advancedEnding_playMusic";
			control = "Checkbox";
			expression = "missionNamespace setVariable ['Enh_advancedEnding_playMusic',_value]";
			defaultValue = "true";
		};
		class Enh_CancelTasks: Enh_PlayMusic
		{
			displayName = $STR_advancedEnding_cancelTasks_displayName;
			tooltip = $STR_advancedEnding_cancelTasks_tooltip;
			property = "Enh_advancedEnding_cancelTasks";
			expression = "missionNamespace setVariable ['Enh_advancedEnding_cancelTasks',_value]";
		};
	};
};
