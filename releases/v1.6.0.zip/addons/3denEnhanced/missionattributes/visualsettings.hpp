class Enh_VisualSettings
{
	displayName = $STR_visualSettings_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_ViewDistance
		{
			displayName = $STR_viewDistance_displayName;
			tooltip = $STR_viewDistance_tooltip;
			property = "Enh_viewDistance";
			control = "Edit";
			expression = "if (!is3DEN && (_value > 0)) then {_value remoteExec ['setViewDistance',[0,-2] select (isMultiplayer && isDedicated),true]}";
			defaultValue = "-1";
			typeName = "NUMBER";
		};
		class Enh_DisableGrass
		{
			displayName = $STR_disableGrass_displayName;
			tooltip = $STR_disableGrass_tooltip;
			property = "Enh_disableGrass";
			control = "Checkbox";
			expression = "if(_value) then {50 remoteExec ['setTerrainGrid',[0,-2] select (isMultiplayer && isDedicated),true]}";
			defaultValue = "false";
		};
	};
};
