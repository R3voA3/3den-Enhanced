class Enh_AmbientFlyby
{
	displayName = $STR_ambientFlyby_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_Type
		{
			displayName = $STR_ambientFlyby_type_displayName;
			tooltip =$STR_ambientFlyby_type_tooltip;
			property = "Enh_ambientFlyby_type";
			control = "EditArray";
			expression =
			"\
				if (!(_value isEqualTo []) && !is3DEN) then\
				{\
					_value spawn\
					{\
						waitUntil {time > 0.2};\
						\
						_startPos = missionNamespace getVariable 'Enh_ambientFlyby_startPos',\
						_endPos = missionNamespace getVariable 'Enh_ambientFlyby_endPos',\
						_alt = missionNamespace getVariable 'Enh_ambientFlyby_altitude',\
						_speed = missionNamespace getVariable 'Enh_ambientFlyby_speed',\
						_side = ([EAST,WEST,INDEPENDENT,CIVILIAN] select (missionNamespace getVariable 'Enh_ambientFlyby_side'));\
						_delay = (missionNamespace getVariable 'Enh_ambientFlyby_delay');\
						\
						for '_i' from 0 to (missionNamespace getVariable 'Enh_ambientFlyby_iterations') do\
						{\
							sleep _delay;\
							[_startPos,_endPos,_alt,_speed,selectRandom _this,_side] call BIS_fnc_ambientFlyby;\
						};\
					};\
				};\
			";
			defaultValue = [];
		};
		class Enh_Side
		{
			displayName = $STR_ambientFlyby_side_displayName;
			tooltip = "";
			property = "Enh_ambientFlyby_side";
			control = "Enh_SideToolBox";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_side',_value]";
			defaultValue = "1";
			typeName = "NUMBER";
		};
		class Enh_StartPos
		{
			displayName = $STR_ambientFlyby_startPosition_displayName;
			tooltip = "";
			property = "Enh_ambientFlyby_startPos";
			control = "EditXYZ";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_startPos',_value]";
			defaultValue = "[0,0,0]";
		};
		class Enh_EndPos
		{
			displayName = $STR_ambientFlyby_endPosition_displayName;
			tooltip = "";
			property = "Enh_ambientFlyby_endPos";
			control = "EditXYZ";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_endPos',_value]";
			defaultValue = "[1000,1000,0]";
		};
		class Enh_Altitude
		{
			displayName = $STR_ambientFlyby_altitude_displayName;
			tooltip = $STR_ambientFlyby_altitude_tooltip;
			property = "Enh_ambientFlyby_altitude";
			control = "EditZ";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_altitude',_value]";
			defaultValue = "100";
			typeName = "NUMBER";
		};
		class Enh_Speed
		{
			displayName = $STR_ambientFlyby_speed_displayName;
			tooltip = $STR_ambientFlyby_speed_tooltip;
			property = "Enh_ambientFlyby_speed";
			control = "SpeedModeGroup";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_speed',_value]";
			defaultValue = "normal";
			typeName = "STRING";
		};
		class Enh_Iterations
		{
			displayName = $STR_ambientFlyby_iterations_displayName;
			tooltip = "";
			property = "Enh_ambientFlyby_iterations";
			control = "Edit";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_iterations',_value]";
			defaultValue = "1";
			typeName = "NUMBER";
		};
		class Enh_Delay
		{
			displayName = $STR_ambientFlyby_delay_displayName;
			tooltip = $STR_ambientFlyby_delay_tooltip;
			property = "Enh_ambientFlyby_Delay";
			control = "SliderTime";
			expression = "missionNamespace setVariable ['Enh_ambientFlyby_delay',_value]";
			defaultValue = "360";
			typeName = "NUMBER";
		};
	};
};
