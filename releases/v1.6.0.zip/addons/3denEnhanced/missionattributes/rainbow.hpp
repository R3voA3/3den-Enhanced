class Enh_RainbowStrength
{
	displayName = $STR_rainbow_displayName;
	tooltip = $STR_rainbow_tooltip;
	property = "Enh_rainbowStrength";
	control = "Slider";
	expression = "0 setRainBow _value";
	defaultValue = rainbow;
};
