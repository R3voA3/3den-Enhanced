class Enh_SaveGear
{
   displayName = $STR_saveGearAllPlayers_displayName;
   tooltip = $STR_saveGearAllPlayers_tooltip;
   property = "Enh_saveGearPlayers";
   control = "Checkbox";
   expression =
   "\
      if (!is3DEN && _value && isMultiplayer) then\
      {\
         {\
            if (isNil {player getVariable 'Enh_savedLoadout'}) then\
            {\
               player setVariable ['Enh_savedLoadout',getUnitloadout player];\
               player addEventHandler ['respawn',{player setUnitLoadout (player getVariable 'Enh_savedLoadout')}];\
            };\
         } remoteExec ['call',[0,-2] select (isMultiplayer && isDedicated),true];\
      };\
   ";
   defaultValue = "false";
};
