class CfgPatches
{
	class 3denEnhanced
	{
		name = "3den Enhanced";
		author = "Revo";
		url = "https://forums.bistudio.com/topic/188312-3den-enhanced/";
		requiredVersion = 1.60;
		requiredAddons[] = {3den};
		units[] = {};
		weapons[] = {};
      	worlds[] = {};
	};
};
