class CfgFunctions
{
	class Enh
	{
		class ContextMenu
		{
			file="3denEnhanced\functions";
			class logClassName {};
			class setRandomDir {};
			class hideMapObjects {};
			class garrisonNearest {};
			class logFactionClassName {};
		};
		class Attributes
		{
			file="3denEnhanced\functions";
			class playMusic {};
		};
		class Misc
		{
			file="3denEnhanced\functions";
			class checkVersion {};
			class initPreferences {};
		};
		class Controls
		{
			file="3denEnhanced\functions";
			class attributeLoadCombo {};
			class attributeSaveCombo {};
			class attributeLoadInsigniaCombo {};
			class fillVehicleTypeCombo {};
			class fillMarkerTypeCombo {};
			class fillCfgDebriefingCombo {};
		};
	};
};
