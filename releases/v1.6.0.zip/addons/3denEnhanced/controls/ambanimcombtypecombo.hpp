class Enh_AmbAnimCombTypeCombo: Title
{
	attributeLoad = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeLoadCombo";
	attributeSave = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeSaveCombo";

	class Controls: Controls
	{
		class Title: Title{};
		class Value: ctrlCombo
		{
			idc = 100;
			x = ATTRIBUTE_TITLE_W * GRID_W;
			w = ATTRIBUTE_CONTENT_W * GRID_W;
			h = SIZE_M * GRID_H;

			class Items
			{
				class NoChange
				{
					text = $STR_noChange_displayName;
					data = "NOCHANGE";
					default = 1;
				};
				class STAND
				{
					text = $STR_ambAnimCombo_stand;
					data = "STAND";
				};
				class STAND_IA
				{
					text = $STR_ambAnimCombo_standIA;
					data = "STAND_IA";
				};
				class SIT_LOW
				{
					text = $STR_ambAnimCombo_sitLow;
					data = "SIT_LOW";
				};
				class KNEEL
				{
					text = $STR_ambAnimCombo_kneel;
					data = "KNEEL";
				};
				class LEAN
				{
					text = $STR_ambAnimCombo_lean;
					data = "LEAN";
				};
				class WATCH
				{
					text = $STR_ambAnimCombo_watch;
					data = "WATCH";
				};
				class WATCH1
				{
					text = $STR_ambAnimCombo_watch1;
					data = "WATCH1";
				};
				class WATCH2
				{
					text = $STR_ambAnimCombo_watch2;
					data = "WATCH2";
				};
			};
		};
	};
};
