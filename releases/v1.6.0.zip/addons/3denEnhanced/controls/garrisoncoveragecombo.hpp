class Enh_GarrisonCoverageCombo : Title
{
	attributeLoad = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeLoadCombo";
	attributeSave = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeSaveCombo";

	class Controls : Controls
	{
		class Title : Title {};
		class Value : ctrlCombo
		{
			idc = 100;
			x = ATTRIBUTE_TITLE_W * GRID_W;
			w = ATTRIBUTE_CONTENT_W * GRID_W;
			h = SIZE_M * GRID_H;

			class Items
			{
				class coverage_100
				{
					text = "100 %";
					data = 1;
					default = 1;
				};
				class coverage_50
				{
					text = "50 %";
					data = 2;
				};
				class coverage_30
				{
					text = "30 %";
					data = 3;
				};
				class coverage_20
				{
					text = "20 %";
					data = 5;
				};
			};
		};
	};
};
