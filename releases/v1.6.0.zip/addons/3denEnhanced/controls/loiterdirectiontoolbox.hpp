class Enh_LoiterDirectionToolbox: Title
{
	attributeLoad = "(_this controlsGroupCtrl 100) lbsetcursel _value";
	attributeSave = "missionnamespace getvariable ['Enh_LoiterDirection_value',0]";
	h = "10 * pixelH * pixelGrid * 0.25";

	class Controls: Controls
	{

		class Title: Title
		{
			h = "10 * pixelH * pixelGrid * 0.25";
		};
		class Value: ctrlToolboxPicture
		{
			idc = 100;
			x = "48 * pixelW * pixelGrid * 0.25";
			w = "82 * pixelW * pixelGrid * 0.25";
			h = "10 * pixelH * pixelGrid * 0.25";
			values[] = {0,1};
			default = 0;
			columns = 2;
			onToolboxSelChanged = "missionnamespace setvariable ['Enh_LoiterDirection_value',_this select 1]";
			strings[] = {"\a3\3DEN\Data\Attributes\LoiterDirection\ccw_ca.paa","\a3\3DEN\Data\Attributes\LoiterDirection\cw_ca.paa"};
			style = "0x02 + 0x30 + 0x800";
		};
	};
};
