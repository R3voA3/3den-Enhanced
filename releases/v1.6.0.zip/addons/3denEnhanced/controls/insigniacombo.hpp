class Enh_InsigniaCombo: Title
{
	attributeLoad = "[_this controlsGroupCtrl 100,_this controlsGroupCtrl 101] call Enh_fnc_attributeLoadInsigniaCombo"
	attributeSave = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeSaveCombo";
	h = ATTRIBUTE_CONTENT_W * GRID_W * 0.75;

	class Controls: Controls
	{
		class Title: Title {};
		class Value: ctrlCombo
		{
			idc = 100;
			x = ATTRIBUTE_TITLE_W * GRID_W;
			w = ATTRIBUTE_CONTENT_W * GRID_W;
			h = SIZE_M * GRID_H;
			onLBSelChanged =
			"\
				_ctrl = _this select 0;\
				_index = _this select 1;\
				_ctrlPicture = (ctrlParentControlsGroup _ctrl) controlsGroupCtrl 101;\
				_texture =  (missionNamespace getVariable 'Enh_insigniaTextures') select _index;\
				_ctrlPicture ctrlSetText _texture;\
			";
		};
		class Picture: ctrlStaticPicture
		{
			idc = 101;
			x = ATTRIBUTE_CONTENT_W * GRID_W / 1.2
			y = SIZE_M * GRID_H * 1.2;
			w = ATTRIBUTE_CONTENT_W * GRID_W / 2;
			h = ATTRIBUTE_CONTENT_W * GRID_W / 2;
		};
	};
};
