class Enh_AmbAnimEquipmentCombo: Title
{
	attributeLoad = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeLoadCombo";
	attributeSave = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeSaveCombo";

	class Controls: Controls
	{
		class Title: Title{};
		class Value: ctrlCombo
		{
			idc = 100;
			x = ATTRIBUTE_TITLE_W * GRID_W;
			w = ATTRIBUTE_CONTENT_W * GRID_W;
			h = SIZE_M * GRID_H;

			class Items
			{
				class ASIS
				{
					text = $STR_ambAnimEquipCombo_asis;
					data = "ASIS";
					default = 1;
				};
				class RANDOM
				{
					text = $STR_ambAnimEquipCombo_random;
					data = "RANDOM";
				};
				class LIGHT
				{
					text = $STR_ambAnimEquipCombo_light;
					data = "LIGHT";
				};
				class MEDIUM
				{
					text = $STR_ambAnimEquipCombo_medium;
					data = "MEDIUM";
				};
				class FULL
				{
					text = $STR_ambAnimEquipCombo_full;
					data = "FULL";
				};
				class NONE
				{
					text = $STR_ambAnimEquipCombo_none;
					data = "NONE";
				};
			};
		};
	};
};
