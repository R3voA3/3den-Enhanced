class Enh_UnitTraitsCombo: Title
{
	attributeLoad = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeLoadCombo";
	attributeSave = "[_this controlsGroupCtrl 100,_config] call Enh_fnc_attributeSaveCombo";

	class Controls: Controls
	{
		class Title: Title{};
		class Value: ctrlCombo
		{
			idc = 100;
			x = ATTRIBUTE_TITLE_W * GRID_W;
			w = ATTRIBUTE_CONTENT_W * GRID_W;
			h = SIZE_M * GRID_H;

			class Items
			{
				class NoChange
				{
					text = $STR_noChange_displayName;
					data = "noChange";
					default = 1;
				};
				class Yes
				{
					text = $STR_yes_displayName
					data = "yes";
				};
				class No
				{
					text = $STR_no_displayName;
					data = "no";
				};
			};
		};
	};
};
