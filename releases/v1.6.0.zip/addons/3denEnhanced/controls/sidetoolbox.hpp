class Enh_SideToolBox: Title
{
	attributeLoad = "(_this controlsGroupCtrl 100) lbsetcursel _value";
	attributeSave = "missionnamespace getvariable ['Enh_SideToolBox_value',1]";
	h = "10 * pixelH * pixelGrid * 0.25";

	class Controls: Controls
	{

		class Title: Title
		{
			h = "10 * pixelH * pixelGrid * 0.25";
		};
		class Value: ctrlToolboxPicture
		{
			idc = 100;
			x = "48 * pixelW * pixelGrid * 0.25";
			w = "82 * pixelW * pixelGrid * 0.25";
			h = "10 * pixelH * pixelGrid * 0.25";
			values[] = {0,1,2,3};
			default = 1;
			columns = 4;
			onToolboxSelChanged = "missionnamespace setvariable ['Enh_SideToolBox_value',_this select 1]";
			strings[] =
			{
				"\a3\3DEN\Data\Displays\Display3DEN\PanelRight\side_east_ca.paa",
				"\a3\3DEN\Data\Displays\Display3DEN\PanelRight\side_west_ca.paa",
				"\a3\3DEN\Data\Displays\Display3DEN\PanelRight\side_guer_ca.paa",
				"\a3\3DEN\Data\Displays\Display3DEN\PanelRight\side_civ_ca.paa"
			};
			style = "0x02 + 0x30 + 0x800";
		};
	};
};
