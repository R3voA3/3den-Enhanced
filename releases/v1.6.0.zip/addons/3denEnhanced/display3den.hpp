class ctrlMenuStrip;
class ctrlMenu;
class display3DEN
{
	class Controls
	{
		class MenuStrip: ctrlMenuStrip
		{
			class Items
			{
				class Help
				{
					items[] += {"Help3denEnhanced","HelpFunctionsList","HelpAssets"};
				};
				class Tools
				{
					items[] += {"Enh_toolFolder"};
				};
				class Enh_toolFolder
				{
					text = $STR_toolFolder_displayName;
					picture = "\3denEnhanced\data\Enh_icon_iconSmall.paa";
					items[] += {"Enh_toggleMapIDs","Enh_recompileFunctions","Enh_logFactionNames"};
				};
				class Enh_toggleMapIDs
				{
					text = $STR_showMapIDs_displayName;
					picture = "\3denEnhanced\data\Enh_icon_id.paa";
					action = "do3DENAction 'ToggleMapIDs';";
				};
				class Enh_recompileFunctions
				{
					text = $STR_recompileFunctions_displayName;
					picture = "\a3\3DEN\Data\Displays\Display3DEN\EntityMenu\functions_ca.paa";
					action = "1 call BIS_fnc_recompile; ['functionsRecompiled'] call BIS_fnc_3DENNotification";
				};
				class Enh_logFactionNames
				{
					text = "Log Faction Names";
					picture = "\3denEnhanced\data\Enh_icon_clipboard.paa";
					action = "call Enh_fnc_logFactionClassName";
				};
				class Help3denEnhanced
				{
					text = $STR_Help3denEnhanced;
					picture = "\a3\3DEN\Data\Controls\ctrlMenu\link_ca.paa";
					weblink = "https://forums.bistudio.com/topic/188312-3den-enhanced/";
				};
				class HelpFunctionsList
				{
					text = $STR_HelpFunctionsOverview;
					picture = "\a3\3DEN\Data\Controls\ctrlMenu\link_ca.paa";
					weblink = "https://community.bistudio.com/wiki/Category:Arma_3:_Functions";
				};
				class HelpAssets
				{
					text = $STR_HelpAssets;
					picture = "\a3\3DEN\Data\Controls\ctrlMenu\link_ca.paa";
					weblink = "https://community.bistudio.com/wiki/Arma_3_Assets";
				};
			};
		};
	};
	class ContextMenu: ctrlMenu
	{
		class Items
		{
			class Log
			{
				picture = "\3denEnhanced\data\Enh_icon_clipboard.paa";
				items[] += {"LogClassName"};
			};
			class Edit
			{
				items[] += {"SetRandomDir","GarrisonBuildings","HideMapObjects"};
			};
			class LogClassName
			{
				action = "call Enh_fnc_logClassName";
				Text = $STR_LogClassName;
				conditionShow = "selectedObject + selectedLogic";
			};
			class SetRandomDir
			{
				action = "call Enh_fnc_setRandomDir";
				Text = $STR_SetRandomDir;
				conditionShow = "selectedObject + selectedWaypoint + selectedLogic + selectedMarker";
			};
			class GarrisonBuildings
			{
				action = "call Enh_fnc_garrisonNearest";
				Text = $STR_GarrisonBuilding;
				conditionShow = "selectedObject";
			};
			class HideMapObjects
			{
				action = "call Enh_fnc_hideMapObjects";
				Text = $STR_hideMapObjects;
			};
		};
	};
};
