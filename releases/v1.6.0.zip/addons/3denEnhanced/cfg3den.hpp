#include "\a3\3DEN\UI\macros.inc"
//Bases classes for all controls
class ctrlCombo;
class ctrlStatic;
class ctrlEdit;
class ctrlXSliderH;
class ctrlCheckbox;
class ctrlToolboxPicture;
class ctrlStaticPicture;

class Cfg3DEN
{
	#include "notifications.hpp"

	class EventHandlers
	{
		class Enh_EH_checkVersion
		{
			onMissionNew = "call Enh_fnc_checkVersion";
		};
		class Enh_EH_enableMusic
		{
			onTerrainNew = "['enableMusic'] spawn Enh_fnc_initPreferences";
			onMissionPreviewEnd = "['enableMusic'] spawn Enh_fnc_initPreferences";
		};
		class Enh_EH_preloadArsenal
		{
			onTerrainNew = "['preloadArsenal'] spawn Enh_fnc_initPreferences";
			onMissionPreviewEnd = "['preloadArsenal'] spawn Enh_fnc_initPreferences";
		};
	};
	class Attributes
	{
		// Base class templates
		class Default;
		class Title: Default
		{
			class Controls
			{
				class Title;
			};
		};
		#include "controls\ambAnimCombTypeCombo.hpp"
		#include "controls\ambAnimEquipCombo.hpp"
		#include "controls\ambAnimTypeCombo.hpp"
		#include "controls\garrisonCoverageCombo.hpp"
		#include "controls\sliderTimeMultiplier.hpp"
		#include "controls\unitTraitsCombo.hpp"
		#include "controls\loiterDirectionToolbox.hpp"
		#include "controls\insigniaCombo.hpp"
		#include "controls\sliderGarrisonRadius.hpp"
		#include "controls\MarkerTypeCombo.hpp"
		#include "controls\AirVehicleCombo.hpp"
		#include "controls\sideToolBox.hpp"
		#include "controls\CfgDebriefingCombo.hpp"
	};
	class Mission
	{
		class Intel
		{
			class AttributeCategories
			{
				class Rain
				{
					class Attributes
					{
						#include "missionAttributes\rainbow.hpp"
					};
				};
				#include "missionAttributes\timeMultiplier.hpp"
				#include "missionAttributes\visualSettings.hpp"
				#include "missionAttributes\enableEnvironment.hpp"
				#include "missionAttributes\advancedFog.hpp"
			};
		};
		class Scenario
		{
			class AttributeCategories
			{
				#include "missionAttributes\volume.hpp"
				#include "missionAttributes\introText.hpp"
				#include "missionAttributes\establishingShot.hpp"
				#include "missionAttributes\ambientFlyby.hpp"
				#include "missionAttributes\advancedEnding.hpp"
			};
		};
		class Preferences
		{
			class AttributeCategories
			{
				#include "missionAttributes\music.hpp"
				#include "missionAttributes\garrisonBuildings.hpp"
				class Misc
				{
					class Attributes
					{
						#include "missionAttributes\preloadArsenal.hpp"
					};
				};
			};
		};
		class Multiplayer
		{
			class AttributeCategories
			{
				class Respawn
				{
					class Attributes
					{
						#include "missionAttributes\saveGearAllPlayers.hpp"
						#include "missionAttributes\respawnTickets.hpp"
					};
				};
				#include "missionAttributes\dynamicGroups.hpp"
			};
		};
	};
	class Object
	{
		class AttributeCategories
		{
			#include "objectAttributes\advancedDamageUnit.hpp"
			#include "objectAttributes\advancedDamageVehicle.hpp"
			#include "objectAttributes\randomPatrol.hpp"
			#include "objectAttributes\disableAI.hpp"
			#include "objectAttributes\ambientAnimation.hpp"
			#include "objectAttributes\ambientAnimationCombat.hpp"
			#include "objectAttributes\advancedSkill.hpp"
			#include "objectAttributes\unitTraits.hpp"
			#include "objectAttributes\onEventCode.hpp"
			#include "objectAttributes\unitMarker.hpp"

			class StateSpecial
			{
				class Attributes
				{
					#include "objectAttributes\setCaptive.hpp"
					#include "objectAttributes\allowSprint.hpp"
					#include "objectAttributes\disableBISRevive.hpp"
					#include "objectAttributes\makeHostage.hpp"
					#include "objectAttributes\enableHeadlights.hpp"
					#include "objectAttributes\allowCrewInImmobile.hpp"
					#include "objectAttributes\engineOn.hpp"
					#include "objectAttributes\disableNVGE.hpp"
					#include "objectAttributes\disableTIE.hpp"
					#include "objectAttributes\limitSpeed.hpp"
					//#include "objectAttributes\createSimpleObject.hpp" Doesn't work properly yet, maybe later, maybe never
				};
			};
			class Identity
			{
				class Attributes
				{
					#include "objectAttributes\insignia.hpp"
				};
			};
			class Inventory
			{
				class Attributes
				{
					#include "objectAttributes\removeWeapons.hpp"
					#include "objectAttributes\clearInventory.hpp"
					#include "objectAttributes\removeFAKs.hpp"
					#include "objectAttributes\removeNVG.hpp"
					#include "objectAttributes\removeMap.hpp"
					#include "objectAttributes\removeGPS.hpp"
					#include "objectAttributes\addGunLight.hpp"
					#include "objectAttributes\arsenal.hpp"
					#include "objectAttributes\clearVehCargo.hpp"
				};
			};
			class State
			{
				class Attributes
				{
					#include "objectAttributes\stance.hpp"
					#include "objectAttributes\fatigue.hpp"
					#include "objectAttributes\suppression.hpp"
					#include "objectAttributes\allowFleeing.hpp"
					#include "objectAttributes\setMass.hpp"
				};
			};
		};
	};
};
