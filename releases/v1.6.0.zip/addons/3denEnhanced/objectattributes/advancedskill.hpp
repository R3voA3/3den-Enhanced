class AdvancedSkill
{
	displayName = $STR_advancedSkill_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_AimingShake
		{
			displayName = $STR_aimingShake_displayName;
			tooltip = $STR_aimingShake_tooltip;
			property = "Enh_aimingShake";
			expression = "_this setSkill ['AimingShake',_value]";
			control = "Skill";
			defaultValue = "0.5";
			condition = "objectControllable";
		};
		class Enh_AimingSpeed: Enh_AimingShake
		{
			displayName = $STR_aimingSpeed_displayName;
			tooltip = $STR_aimingSpeed_tooltip;
			property = "Enh_aimingSpeed";
			expression = "_this setSkill ['aimingSpeed',_value]";
		};
		class Enh_AimingAccuracy: Enh_AimingShake
		{
			displayName = $STR_aimingAccuracy_displayName;
			tooltip = $STR_aimingAccuracy_tooltip;
			property = "Enh_aimingAccuracy";
			expression = "_this setSkill ['aimingAccuracy',_value]";
		};
		class Enh_Commanding: Enh_AimingShake
		{
			displayName = $STR_commanding_displayName;
			tooltip = $STR_commanding_tooltip;
			property = "Enh_commanding";
			expression = "_this setSkill ['commanding',_value]";
		};
		class Enh_Courage: Enh_AimingShake
		{
			displayName = $STR_courage_displayName;
			tooltip = $STR_courage_tooltip;
			property = "Enh_courage";
			expression = "_this setSkill ['courage',_value]";
		};
		class Enh_General: Enh_AimingShake
		{
			displayName = $STR_general_displayName;
			tooltip = $STR_general_tooltip;
			property = "Enh_general";
			expression = "_this setSkill ['general',_value]";
		};
		class Enh_ReloadSpeed: Enh_AimingShake
		{
			displayName = $STR_reloadSpeed_displayName;
			tooltip = $STR_reloadSpeed_tooltip;
			property = "Enh_reloadingSpeed";
			expression = "_this setSkill ['reloadSpeed',_value]";
		};
		class Enh_SpotDistance: Enh_AimingShake
		{
			displayName = $STR_spotDistance_displayName;
			tooltip = $STR_spotDistance_tooltip;
			property = "Enh_spotDistance";
			expression = "_this setSkill ['spotDistance',_value]";
		};
		class Enh_SpotTime: Enh_AimingShake
		{
			displayName = $STR_spotTime_displayName;
			tooltip = $STR_spotTime_tooltip;
			property = "Enh_spotTime";
			expression = "_this setSkill ['spotTime',_value]";
		};
	};
};
