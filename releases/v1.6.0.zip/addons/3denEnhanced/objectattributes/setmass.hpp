class Enh_SetMass
{
	displayName = $STR_setMass_displayName;
	tooltip = $STR_setMass_tooltip;
	property = "Enh_setMass";
	control = "Slider";
	expression = "if (_value < 1 && !is3DEN) then {_this setMass ((getMass _this) * _value)};";
	defaultValue = "1";
	condition = "objectVehicle";
};
