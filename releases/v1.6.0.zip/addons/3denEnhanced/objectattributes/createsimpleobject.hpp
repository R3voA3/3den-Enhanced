class Enh_CreateSimpleObject: Enh_SetCaptive
{
	displayName = "Simple Object";
	tooltip = "A simple object has minmal simulation and causes nearly no network traffic. Can be used to populate scnearios with minmal performance impact";
	property = "Enh_createSimpleObject";
	expression =
	"\
		if (_value && !is3DEN) then\
		{\
			_model = (getModelInfo _this) select 1;\
			_pos = getPosWorld _this;\
			_vector = [vectorDir _this,vectorUp _this];\
			_dir = getDir _this;\
			deleteVehicle _this;\
			\
			_simpleObj = createSimpleObject [_model,_pos];\
			_simpleObj setVectorDirAndUp _vector;\
			_simpleObj setDir (_dir + 180);\
		};\
	";
	condition = "objectSimulated + objectDestructable";
	defaultValue = "false";
};
