class Enh_EngineOn: Enh_SetCaptive
{
	displayName = $STR_engineOn_displayName;
	tooltip = "";
	property = "Enh_engineOn";
	expression = "_this engineOn _value";
	condition = "objectVehicle";
};