class Enh_DisableBISRevive: Enh_SetCaptive
{
	displayName = $STR_disableBISRevive_displayName;
	tooltip = $STR_disableBISRevive_tooltip;
	property = "Enh_disableBISRevive";
	expression = "_this setVariable ['BIS_revive_disableRevive',_value]";
};