class Enh_UnitMarker
{
	displayName = $STR_unitMarker_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_Activate
		{
			displayName = $STR_advancedFog_activate_displayName;
			tooltip = $STR_unitMarker_activate_tooltip;
			property = "Enh_unitMarker_activate";
			control = "CheckboxState";
			expression =
			"\
				if (_value && !is3DEN) then\
				{\
					[_this] spawn\
					{\
						_unit = _this param [0,objNull,[objNull]];\
						waitUntil {time > 0.2};\
						\
						_interval = _unit getVariable ['Enh_unitMarker_updateInterval',1];\
						\
						_markerName = format ['Enh_unitMarker_%1',random 1000000];\
						_marker =  createMarker [_markerName,position _unit];\
						\
						_marker setMarkerType  (_unit getVariable ['Enh_unitMarker_type','b_unknown']);\
						_marker setMarkerColor (_unit getVariable ['Enh_unitMarker_colour','colorBLUFOR']);\
						_marker setMarkerSize  (_unit getVariable 'Enh_unitMarker_size');\
						_marker setMarkerAlpha (_unit getVariable ['Enh_unitMarker_alpha',1]);\
						\
						if ((_unit getVariable 'Enh_unitMarker_text') == '') then\
						{\
							_marker setMarkerText (name _unit);\
						}\
						else\
						{\
							_marker setMarkerText (_unit getVariable 'Enh_unitMarker_text');\
						};\
						\
						while {_unit getVariable ['Enh_unitMarker_isAlive',true]} do\
						{\
							if !(alive _unit) then\
							{\
								_unit setVariable ['Enh_unitMarker_isAlive',false];\
								deleteMarker _marker;\
							}\
							else\
							{\
								_marker setMarkerPos (getPosWorld _unit);\
								sleep _interval;\
							};\
						};\
					};\
				};\
			";
			condition = "objectControllable + objectVehicle";
			defaultValue = "false";
		};
		class Enh_MarkerType
		{
			displayName = $STR_unitMarker_type_displayName;
			tooltip = "";
			property = "Enh_unitMarker_markerType";
			control = "Enh_MarkerTypeCombo";
			expression = "_this setVariable ['Enh_unitMarker_type',_value]";
			condition = "objectControllable + objectVehicle";
			defaultValue = "b_unknown";
			typeName = "STRING";
		};
		class Enh_MarkerColour: Enh_MarkerType
		{
			displayName = $STR_unitMarker_colour_displayName;
			property = "Enh_unitMarker_colour";
			control = "MarkerColor";
			expression = "_this setVariable ['Enh_unitMarker_colour',_value]";
			defaultValue = "colorBLUFOR";
			typeName = "STRING";
		};
		class Enh_MarkerAlpha: Enh_MarkerType
		{
			displayName = $STR_unitMarker_alpha_displayName;
			property = "Enh_unitMarker_alpha";
			control = "Slider";
			expression = "_this setVariable ['Enh_unitMarker_alpha',_value]";
			defaultValue = "1";
		};
		class Enh_UpdateInterval: Enh_MarkerType
		{
			displayName = $STR_unitMarker_updateInterval_displayName;
			tooltip = $STR_unitMarker_updateInterval_tooltip;
			property = "Enh_unitMarker_updateInterval";
			control = "Edit";
			expression = "_this setVariable ['Enh_unitMarker_updateInterval',_value]";
			defaultValue = "1";
			typeName = "NUMBER";
		};
		class Enh_MarkerText: Enh_MarkerType
		{
			displayName = $STR_unitMarker_text_displayName;
			tooltip = $STR_unitMarker_text_tooltip;
			property = "Enh_unitMarker_markerText";
			control = "Edit";
			expression = "_this setVariable ['Enh_unitMarker_text',_value]";
			typeName = "STRING";
		};
		class Enh_MarkerSize: Enh_MarkerType
		{
			displayName = $STR_unitMarker_size_displayName;
			property = "Enh_unitMarker_size";
			control = "EditAB";
			expression = "_this setVariable ['Enh_unitMarker_size',_value]";
			defaultValue = "[1,1]";
		};
	};
};
