class Enh_AllowSprint: Enh_SetCaptive
{
	displayName = $STR_allowSprinting_displayName;
	tooltip = $STR_allowSprinting_tooltip;
	property = "Enh_allowSprint";
	expression = "_this allowSprint _value;";
	defaultValue = "true";
};
