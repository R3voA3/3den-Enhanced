class Enh_DisableTIE: Enh_SetCaptive
{
	displayName = $STR_disableTIEquipment_displayName;
	tooltip = $STR_disableTIEquipment_tooltip;
	property = "Enh_disableTIEquipment";
	expression = "_this disableTIEquipment _value";
	condition = "objectVehicle";
};
