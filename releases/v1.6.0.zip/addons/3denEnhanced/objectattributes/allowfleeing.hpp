class Enh_AllowFleeing
{
	displayName = $STR_allowFleeing_displayName;
	tooltip = $STR_allowFleeing_tooltip;
	property = "Enh_allowFleeing";
	control = "Slider";
	condition = "objectControllable"
	expression = "_this allowFleeing _value";
	defaultValue = "0.5";
};
