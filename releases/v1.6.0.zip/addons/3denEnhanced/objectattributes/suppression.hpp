class Enh_Suppression: Enh_Fatigue
{
	displayName = $STR_suppression_displayName;
	tooltip = "";
	property = "Enh_setSuppression";
	expression = "_this setSuppression _value;";
};
