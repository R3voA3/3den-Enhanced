class Enh_AmbientAnimation
{
	displayName = $STR_ambientAnimations_headline;
	collapsed = 1;
	class Attributes
	{
		class Type
		{
			displayName = $STR_ambAnim_animation_displayName;
			tooltip = "";
			property = "Enh_animType";
			control = "Enh_AmbAnimTypeCombo";
			expression =
			"\
				if (is3DEN) then {_this call BIS_fnc_ambientAnim__terminate};\
				if !(_value == 'NOCHANGE') then\
				{\
					[_this,_value] spawn\
					{\
						waitUntil {time > 0.2};\
						[_this select 0,_this select 1,(_this select 0) getVariable 'Enh_animEquipment',objNull] remoteExec ['BIS_fnc_ambientAnim',0,true];\
					};\
				};\
			";
			condition = "objectControllable";
			defaultValue = "NOCHANGE";
			typeName = "STRING";
		};
		class Equipment
		{
			displayName = $STR_ambAnim_equipment_displayName
			tooltip = "";
			property = "Enh_animEquipment";
			control = "Enh_AmbAnimEquipmentCombo";
			expression = "_this setVariable ['Enh_animEquipment',_value];";
			condition = "objectControllable";
			defaultValue = "ASIS";
			typeName = "STRING";
		};
	};
};
