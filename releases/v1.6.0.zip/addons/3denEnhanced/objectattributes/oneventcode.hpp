class Enh_OnEventCode
{
	displayName = $STR_onEventCode_headline;
	collapsed = 1;
	class Attributes
	{
		class Enh_OnRespawnEvent
		{
			displayName = $STR_onRespawnEvent_displayName;
			tooltip = $STR_onRespawnEvent_tooltip;
			property = "Enh_onRespawnEvent";
			control = "EditCodeMulti5";
			expression = "if !(_value == '') then {_this addEventHandler ['respawn',_value]}";
			condition = "objectControllable + objectVehicle";
			typeName = "STRING";
			defaultValue = "";
		};
		class Enh_OnKilledEvent: Enh_OnRespawnEvent
		{
			displayName = $STR_onKilledEvent_displayName;
			tooltip = $STR_onKilledEvent_tooltip;
			property = "Enh_onKilledEvent";
			control = "EditCodeMulti5";
			expression = "if !(_value == '') then {_this addEventHandler ['killed',_value]}";
		};
		class Enh_OnDamagedEvent: Enh_OnRespawnEvent
		{
			displayName = $STR_onDamagedEvent_displayName;
			tooltip = $STR_onDamagedEvent_tooltip;
			property = "Enh_onDamagedEvent";
			control = "EditCodeMulti5";
			expression = "if !(_value == '') then {_this addEventHandler ['dammaged',_value]}";
		};
	};
};
