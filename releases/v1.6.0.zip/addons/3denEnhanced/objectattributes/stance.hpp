class Enh_Stance
{
	displayName = $STR_stance_displayName;
	tooltip = "";
	property = "Enh_unitPos";
	control = "Stance";
	expression = "_this setUnitPos _value";
	condition = "objectControllable";
};