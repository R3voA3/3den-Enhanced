class Enh_RemoveMap: Enh_RemoveWeapons
{
	displayName = $STR_removeMap_displayName;
	tooltip = "";
	property = "Enh_removeMap";
	expression = "if(_value) then {_this unlinkItem 'ItemMap'}";
};