class BIS_AddonInfo
{
	author="76561198015178319";
	timepacked="1464984729";
};
