class Notifications
{
	class LogClassName
	{
		isWarning = 0;
		text = $STR_notifications_LogClassName;
	};
	class checkVersionWarning
	{
		isWarning = 1;
		text = $STR_notifications_checkVersionWarning;
	};
	class functionsRecompiled
	{
		isWarning = 0;
		text = $STR_notifications_functionsRecompiled;
	};
	class factionsLogged
	{
		isWarning = 0;
		text = $STR_notifications_factionsLogged;
	};
};
